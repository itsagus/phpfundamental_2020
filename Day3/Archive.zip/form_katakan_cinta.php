<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Seberapa Kuat Cintamu ?</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  </head>
  <body>
    <div class="" id="card-content">
      <div class="" id="card-title">
        <h2>Seberapa Besar Kekuatan</br> Cintamu ?</h2>
        <div class="underline-title"></div>
      </div>

    <div id="card">
      <div class="" id="card-content">
        <div class="" id="card-title">
          <h4>Isikan data</h4>
          <div class="underline-title"></div>

        </div>
      <form class="form" action="hasil_katakan_cinta.php" method="post">

        <label style="padding-top:13px">&nbsp;Siapa yang kamu cintai ?</label>
        <input class="form-content" type="text" name="siapa" placeholder="" required> <br>
        <div class="form-border"></div>
        <label style="padding-top:22px">&nbsp;Seberapa banyak ?</label>
        <input class="form-content" type="text" name="banyak" placeholder="" required> <br>
        <div class="form-border"></div>
        <input id="submit-btn" type="submit" name="submit" value="Katakan Cinta"> </br>
        <h4>
      </form>
      </div>
    </div>
  </body>
</html>
